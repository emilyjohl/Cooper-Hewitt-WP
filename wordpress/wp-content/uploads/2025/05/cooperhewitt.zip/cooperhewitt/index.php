<?php get_header(); ?>

<main>
  <h1>Search for an Item</h1>
</main>

<?php get_footer(); ?>
