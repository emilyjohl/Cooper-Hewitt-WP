<?php
function cooperhewitt_enqueue_styles() {
    wp_enqueue_style('cooperhewitt-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'mytheme_enqueue_styles');
