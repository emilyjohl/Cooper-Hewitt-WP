<?php
function cooperhewitt_enqueue_styles() {
    wp_enqueue_style('cooperhewitt-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'cooperhewitt_enqueue_styles');
